﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Managar_Work
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e) { }
        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-LQU6CS6\\SQLEXPRESS;database=Workers;Integrated security=sspi");
            con.Open();
            SqlCommand cmd= new SqlCommand("insert into table_Workers values(@ID,@Name)",con);
            cmd.Parameters.AddWithValue("@ID", int.Parse(txtId.Text));
            cmd.Parameters.AddWithValue("@Name", txtName.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("A NEW WORKER HAS ADDED IN THE COMPANY!!!");
        }
        private void btnAllWorkers_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-LQU6CS6\\SQLEXPRESS;database=Workers;Integrated security=sspi");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from table_Workers", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            cmd.ExecuteNonQuery();
            txtId.Text = "";
            txtName.Text = "";
            con.Close();
        }
        private void groupBox1_Enter(object sender, EventArgs e) { }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void txtId_TextChanged(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-LQU6CS6\\SQLEXPRESS;database=Workers;Integrated security=sspi");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete table_Workers where ID=@ID", con);
            cmd.Parameters.AddWithValue("@ID", int.Parse(txtId.Text));
            cmd.ExecuteNonQuery();
            txtId.Text = "";
            txtName.Text = "";
            con.Close();
            MessageBox.Show("THE WORKER HAS BEEN DELETE WITH SUCCESS!!!");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-LQU6CS6\\SQLEXPRESS;database=Workers;Integrated security=sspi");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update table_Workers set Name=@Name where Id=@ID",con);
            cmd.Parameters.AddWithValue("@ID", int.Parse(txtId.Text));
            cmd.Parameters.AddWithValue("@Name",txtName.Text);
            cmd.ExecuteNonQuery();
            txtId.Text = "";
            txtName.Text = "";
            con.Close();
            MessageBox.Show("NAME HAS BEEN CHANGHED WITH SUCCESS!!!");
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-LQU6CS6\\SQLEXPRESS;database=Workers;Integrated security=sspi");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from table_Workers where Name=@Name ", con);
            cmd.Parameters.AddWithValue("@Name", txtName.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;       
            cmd.ExecuteNonQuery();
            con.Close();
            txtId.Text = "";
            txtName.Text = "";
            //MessageBox.Show("Search is work");
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Random rnd = new Random();
            txtId.Text = rnd.Next(0, 1000000).ToString();
        }
        private void btnShowHourWorkers_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-LQU6CS6\\SQLEXPRESS;database=Workers;Integrated security=sspi");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Hour_Worker", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            cmd.ExecuteNonQuery();
            txtId.Text = "";
            txtName.Text = "";
            con.Close();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Welcome w1 = new Welcome();
            w1.Show();
        }
    }
}
